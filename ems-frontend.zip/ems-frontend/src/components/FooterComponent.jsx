import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <span>All rights reserved</span>
        </footer>
    </div>
  )
}

export default FooterComponent